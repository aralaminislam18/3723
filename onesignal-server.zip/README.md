# Meetlity — Free OneSignal push server

এই ফোল্ডারটা `functions/index.js` (Firebase Cloud Function)-এর বিকল্প —
কোনো Blaze plan/billing card ছাড়াই কাজ করে। এটা Render.com-এর ফ্রি tier-এ
হোস্ট করার জন্য বানানো।

## যা যা লাগবে

1. `service-account.json` — Firebase Console > Project settings >
   Service accounts > Generate new private key (OneSignal সেটআপের জন্য
   যেটা আগে ডাউনলোড করেছেন, সেই একই ফাইল)। এই ফাইলটা এই ফোল্ডারে
   `service-account.json` নামে রাখুন।
2. OneSignal App ID এবং REST API Key — OneSignal Dashboard > Settings >
   Keys & IDs
3. Firebase Realtime Database URL — `app/google-services.json`-এ
   `firebase_url` ফিল্ডে আছে (এই প্রজেক্টের জন্য:
   `https://meetlity-3be01-default-rtdb.firebaseio.com`)

## Render.com-এ ডিপ্লয় করার ধাপ (ফ্রি, কার্ড লাগে না)

1. https://render.com -এ গিয়ে GitHub দিয়ে সাইন আপ করুন
2. এই `onesignal-server` ফোল্ডারটা একটা নতুন GitHub রিপোতে পুশ করুন
   (`service-account.json` বাদে — সেটা সরাসরি Render-এর Secret Files
   ফিচারে আপলোড করবেন, GitHub-এ না দেওয়াই ভালো)
3. Render ড্যাশবোর্ডে **New > Web Service** → আপনার রিপো সিলেক্ট করুন
4. Environment: **Node**, Build command: `npm install`,
   Start command: `npm start`
5. **Environment Variables** যোগ করুন:
   - `ONESIGNAL_APP_ID` = আপনার OneSignal App ID
   - `ONESIGNAL_REST_API_KEY` = আপনার OneSignal REST API Key
   - `FIREBASE_DATABASE_URL` = `https://meetlity-3be01-default-rtdb.firebaseio.com`
6. **Secret Files** সেকশনে `service-account.json` আপলোড করুন
   (path: `/etc/secrets/service-account.json`, এবং index.js-এ path
   সেভাবে আপডেট করুন, অথবা সরাসরি `onesignal-server/` ফোল্ডারে ফাইলটা
   রেখে দিন যদি প্রাইভেট রিপো ব্যবহার করেন)
7. **Create Web Service** চাপুন — কয়েক মিনিটে ডিপ্লয় হয়ে যাবে

## ফ্রি tier নোট — Web Service ব্যবহার করুন, Background Worker না

⚠️ Render-এ **Background Worker ফ্রি না** (সর্বনিম্ন $7/মাস)। শুধু
**Web Service**-এর ফ্রি tier আছে, তাই "New" চাপার পর অবশ্যই
**"Web Service"** সিলেক্ট করবেন, "Background Worker" না।

সমস্যা হলো ফ্রি Web Service ১৫ মিনিট নিষ্ক্রিয় থাকলে ঘুমিয়ে যায় —
এটা এড়াতে `index.js`-এ একটা ছোট HTTP health-check সার্ভার যোগ করা
আছে, যাতে Render একে "active web service" হিসেবে চালাতে পারে। এরপর
এটাকে সবসময় জাগিয়ে রাখতে একটা ফ্রি টুল ব্যবহার করুন:

1. https://uptimerobot.com -এ ফ্রি অ্যাকাউন্ট খুলুন (কার্ড লাগবে না)
2. **"Add New Monitor"** → Monitor Type: **HTTP(s)**
3. URL-এ আপনার Render সার্ভিসের ঠিকানা দিন (যেমন
   `https://meetlity-push-server.onrender.com`)
4. Monitoring Interval: **5 minutes**
5. Save করুন

এতে প্রতি ৫ মিনিটে একটা রিকোয়েস্ট যাবে, সার্ভারটা কখনো ঘুমাবে না,
এবং তাই মেসেজ/লাইক/কমেন্ট এলে সাথে সাথে push পাঠাতে পারবে।

## কীভাবে কাজ করে

- Android অ্যাপ (`MainActivity.java`) লগইনের পর `OneSignal.login(uid)`
  কল করে — এতে OneSignal জানে কোন ডিভাইস কোন Firebase uid-এর।
- এই সার্ভার Realtime Database-এ দুই জায়গায় নতুন এন্ট্রি শোনে:
  - `users/{uid}/conversations/{peerUid}/messages/{messageId}` — চ্যাট মেসেজ
  - `users/{uid}/notifications/{notificationId}` — লাইক, কমেন্ট, রিয়্যাকশন,
    ফ্রেন্ড রিকোয়েস্ট ইত্যাদি (bell আইকনের নোটিফিকেশনগুলো)
- নতুন এন্ট্রি পেলে OneSignal-এর REST API-তে কল করে, `external_id`
  দিয়ে সঠিক প্রাপককে টার্গেট করে পুশ পাঠায় — অ্যাপ বন্ধ থাকলেও।

এর মানে অ্যাপে যা যা `NotificationRepository.send(...)` কল করে (লাইক,
কমেন্ট, রিয়্যাকশন, ফ্রেন্ড রিকোয়েস্ট/অ্যাকসেপ্ট, মেসেজ রিকোয়েস্ট, রিল
রিয়্যাকশন/কমেন্ট/শেয়ার — এগুলো ইতিমধ্যেই অ্যাপের ভেতরে কোড করা আছে),
সেগুলোর জন্য অটোমেটিক push notification যাবে, নতুন করে কিছু কোড করা লাগবে
না — শুধু এই সার্ভারটা রিডিপ্লয় করলেই হবে।
